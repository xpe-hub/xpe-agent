const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  setToken: (token) => ipcRenderer.invoke('set-token', token),
  getConfig: () => ipcRenderer.invoke('get-config'),
  createRelease: (data) => ipcRenderer.invoke('create-release', data),
  listReleases: (data) => ipcRenderer.invoke('list-releases', data),
  selectFile: () => ipcRenderer.invoke('select-file'),
  getUserInfo: () => ipcRenderer.invoke('get-user-info')
});
