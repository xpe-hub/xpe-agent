const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const { Octokit } = require('octokit');
const fs = require('fs');
const path = require('path');

let mainWindow;
let octokit = null;

// Load configuration
function loadConfig() {
  const configPath = path.join(__dirname, 'config.json');
  if (fs.existsSync(configPath)) {
    return JSON.parse(fs.readFileSync(configPath, 'utf8'));
  }
  return { githubToken: '', owner: 'xpe-hub' };
}

// Save configuration
function saveConfig(config) {
  fs.writeFileSync(path.join(__dirname, 'config.json'), JSON.stringify(config, null, 2));
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 900,
    height: 700,
    title: 'XPE Agent - GitHub Release Manager',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    frame: true,
    backgroundColor: '#1a1a2e'
  });

  mainWindow.loadFile('index.html');
  
  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// IPC Handlers for GitHub operations
ipcMain.handle('set-token', async (event, token) => {
  const config = loadConfig();
  config.githubToken = token;
  saveConfig(config);
  octokit = new Octokit({ auth: token });
  return { success: true };
});

ipcMain.handle('get-config', async () => {
  return loadConfig();
});

ipcMain.handle('create-release', async (event, data) => {
  try {
    if (!octokit) {
      const config = loadConfig();
      if (config.githubToken) {
        octokit = new Octokit({ auth: config.githubToken });
      } else {
        return { success: false, error: 'GitHub Token no configurado' };
      }
    }

    // Create release
    const { data: release } = await octokit.request('POST /repos/{owner}/{repo}/releases', {
      owner: data.owner,
      repo: data.repo,
      tag_name: data.tag,
      name: data.name || data.tag,
      body: data.body,
      draft: false,
      prerelease: false
    });

    // Upload asset if file provided
    if (data.filePath && fs.existsSync(data.filePath)) {
      const fileContent = fs.readFileSync(data.filePath);
      const fileName = path.basename(data.filePath);
      const contentType = getContentType(fileName);
      
      const uploadUrl = release.upload_url.replace('{?name,label}', `?name=${encodeURIComponent(fileName)}`);
      
      await octokit.request({
        method: 'POST',
        url: uploadUrl,
        headers: {
          'Content-Type': contentType,
          'Content-Length': fileContent.length
        },
        data: fileContent
      });
    }

    return { 
      success: true, 
      url: release.html_url,
      message: 'Release creado con éxito'
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('list-releases', async (event, data) => {
  try {
    if (!octokit) {
      const config = loadConfig();
      if (config.githubToken) {
        octokit = new Octokit({ auth: config.githubToken });
      } else {
        return { success: false, error: 'GitHub Token no configurado' };
      }
    }

    const { data: releases } = await octokit.request('GET /repos/{owner}/{repo}/releases', {
      owner: data.owner,
      repo: data.repo
    });

    return { 
      success: true, 
      releases: releases.map(r => ({
        id: r.id,
        tag: r.tag_name,
        name: r.name,
        url: r.html_url,
        assets: r.assets.map(a => ({ name: a.name, size: a.size, url: a.browser_download_url }))
      }))
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('select-file', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [
      { name: 'All Files', extensions: ['*'] },
      { name: 'Executables', extensions: ['exe', 'dll'] },
      { name: 'Archives', extensions: ['zip', '7z', 'rar'] }
    ]
  });
  
  if (!result.canceled && result.filePaths.length > 0) {
    return { success: true, path: result.filePaths[0] };
  }
  return { success: false };
});

ipcMain.handle('get-user-info', async () => {
  try {
    if (!octokit) {
      const config = loadConfig();
      if (config.githubToken) {
        octokit = new Octokit({ auth: config.githubToken });
      } else {
        return { success: false, error: 'Token no configurado' };
      }
    }

    const { data } = await octokit.request('GET /user');
    return { 
      success: true, 
      login: data.login,
      name: data.name,
      avatar: data.avatar_url
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

function getContentType(filename) {
  const ext = path.extname(filename).toLowerCase();
  const types = {
    '.exe': 'application/x-msdownload',
    '.dll': 'application/x-msdownload',
    '.zip': 'application/zip',
    '.json': 'application/json',
    '.txt': 'text/plain',
    '.md': 'text/markdown'
  };
  return types[ext] || 'application/octet-stream';
}
